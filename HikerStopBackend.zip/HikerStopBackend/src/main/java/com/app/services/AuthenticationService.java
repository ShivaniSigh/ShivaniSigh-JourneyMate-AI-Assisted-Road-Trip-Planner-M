//package com.app.services;
//
//import com.app.pojos.User;
//
//public interface AuthenticationService {
//	
//    User signInAndReturnJWT(User signInRequest);
//}
