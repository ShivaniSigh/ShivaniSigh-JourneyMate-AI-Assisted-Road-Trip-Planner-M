//package com.app.security.Jwt;
//
//
//
//
//import org.springframework.security.core.Authentication;
//
//import com.app.security.UserPrinciple;
//
//import javax.servlet.http.HttpServletRequest;
//
//public interface JwtProviderInterface {
//    String generateToken(UserPrinciple auth);
//
//    Authentication getAuthentication(HttpServletRequest request);
//
//    boolean isTokenValid(HttpServletRequest request);
//}
