package com.app.dto;

import lombok.Data;

@Data
public class CartDTO {

	private int eventid;
	
	
	private String eventcat;
	
	
	private String eventname;
	
	
	private int price;
	
	
	private int qty;
	
		
}
